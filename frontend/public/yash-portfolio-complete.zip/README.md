# 🚀 Yash Tripathi - Portfolio Website

A stunning, modern portfolio website with **amazing visual effects** including animated backgrounds, spotlight effects, and glowing borders.

## ✨ Features

### Visual Effects
- **Animated Background**: Moving grid pattern with floating particles
- **Spotlight Effect**: Mouse-following gradient spotlight
- **Glowing Borders**: Animated neon green borders on project cards
- **Gradient Animations**: Pulsing glow effects on CTA buttons
- **Particle System**: 50+ interconnected particles creating depth

### Multi-Page Structure
- **Home**: Hero section with social links and CTAs
- **About**: Profile, bio, and key stats
- **Experience**: Professional work history
- **Projects**: Featured work including Finance Management System
- **Skills**: Technical expertise organized by category
- **Education**: Academic background and achievements
- **Certificates**: Professional certifications with Drive links
- **Contact**: Contact form and information

### Tech Stack
- **Frontend**: React 19, React Router DOM
- **Styling**: Tailwind CSS, Custom CSS animations
- **UI Components**: Shadcn/ui (50+ components)
- **Icons**: Lucide React
- **Effects**: Custom Canvas animations, CSS gradients

## 🎨 Design Highlights

- **Dark monochrome theme** with neon green (#38FF62) accents
- **JetBrains Mono** for code/tech aesthetic
- **Sharp, rectangular design** (no rounded corners)
- **High contrast** for readability
- **Responsive design** with mobile-first approach
- **Smooth animations** throughout

## 📦 Installation

### Prerequisites
- Node.js (v16 or higher)
- Yarn package manager

### Setup Instructions

1. **Extract the zip file**
   ```bash
   unzip yash-portfolio.zip
   cd frontend
   ```

2. **Install dependencies**
   ```bash
   yarn install
   ```

3. **Set up environment variables**
   - The `.env` file is already included
   - Update `REACT_APP_BACKEND_URL` if needed (default is pre-configured)

4. **Start the development server**
   ```bash
   yarn start
   ```

5. **Open your browser**
   - Navigate to `http://localhost:3000`
   - Enjoy the amazing animations!

## 🔧 Build for Production

```bash
yarn build
```

This creates an optimized production build in the `build` folder.

## 📱 Responsive Design

The portfolio is fully responsive and works beautifully on:
- Desktop (1920px+)
- Laptop (1024px - 1919px)
- Tablet (768px - 1023px)
- Mobile (320px - 767px)

## 🎯 Key Components

### AnimatedBackground.jsx
Creates the moving grid and particle system with WebGL canvas animations.

### SpotlightEffect.jsx
Implements the mouse-following gradient spotlight effect.

### GlowingBorder.jsx
Reusable component for animated glowing borders on cards.

### Header.jsx
Fixed navigation with active page indicators and smooth transitions.

## 🌟 Projects Featured

1. **Finance Management System** (ytb-saving)
   - Track income & expenses
   - Generate reports (daily, weekly, monthly, annual)
   - Multi-payment support (Cash, UPI, Card, Bank Transfer)
   - CSV export functionality

2. **Brain Tumor Detection Using CNN**
   - 98% accuracy in tumor classification
   - AI-powered MRI scan analysis

3. **Online Music Streaming Platform**
   - Real-time collaborative listening
   - Virtual rooms with live comments

4. **Employee Management System**
   - Complete CRUD operations
   - Database integration with SQLite

## 🔗 Links

- **GitHub**: https://github.com/Yash-0810
- **LinkedIn**: https://www.linkedin.com/in/yash-tripathi-0b044b215/
- **Email**: yashtripahti2020w@gmail.com
- **Phone**: +91 809 329 4061
- **Instagram**: @yash.h.h

## 📝 Customization

### Colors
Edit `src/index.css` to change the color scheme:
```css
:root {
  --bg-primary: #0a0a0a;
  --accent-primary: #38FF62;
  /* ... */
}
```

### Content
Update your information in:
- `src/components/About.jsx` - Personal info
- `src/components/Projects.jsx` - Project details
- `src/components/Experience.jsx` - Work history
- `src/components/Skills.jsx` - Technical skills
- `src/components/Education.jsx` - Academic background

## 🐛 Troubleshooting

### Port already in use
```bash
# Kill process on port 3000
npx kill-port 3000
# Then restart
yarn start
```

### Dependencies issues
```bash
# Clean install
rm -rf node_modules yarn.lock
yarn install
```

## 📄 License

This project is open source and available for personal use.

## 🙏 Credits

Built with ❤️ by **Yash Tripathi**

Special thanks to:
- Shadcn/ui for beautiful components
- Lucide for clean icons
- Tailwind CSS for styling

---

**Made with Emergent AI** 🚀

For any questions or support, reach out via email or LinkedIn!
